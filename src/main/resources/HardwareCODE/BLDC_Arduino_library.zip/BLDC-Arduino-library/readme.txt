BLDC Shield for Arduino with TLE9879WXA40
v1.0